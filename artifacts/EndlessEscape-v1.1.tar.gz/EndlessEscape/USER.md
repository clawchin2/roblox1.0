# USER.md

- **Name:** Chinmaya
- **What to call them:** Chinmaya
- **Timezone:** IST (India)
- **Notes:** Building a Roblox monetization pipeline. Portfolio strategy — ship fast, reskin failures, scale winners.

## Context

- Goal: Monetize through Roblox games, targeting kids/teens market
- Strategy: High-volume, fast iteration. 10-14 day build cycles, 48hr reskin on failures
- Revenue target: ₹30L–₹1Cr/month
- First game: **Endless Escape** — obstacle/death run with micro-relief spending model
- Key insight: Low-cost impulse purchases (15-25 Robux) during frustration moments = high conversion
