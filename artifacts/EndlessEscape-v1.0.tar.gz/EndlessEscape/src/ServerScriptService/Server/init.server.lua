-- Main Server Script
-- Initializes all server systems

require(script.Parent.GameManager)

print("[Server] Endless Escape server initialized")